# Synthetic dataset generated from uploaded CSV

This folder contains a synthetic version and noisy variants generated from `2199b6a7-563d-42f8-8fb0-287828054b91.csv`.

## What is preserved

- Original CSV shape: `29 rows x 475 columns`
- First-column labels
- Timestamp row: `True`
- Column names
- General numerical range and temporal smoothness

## Files

- `synthetic_2199b6a7-563d-42f8-8fb0-287828054b91.csv`: synthetic dataset with the same structure as the uploaded CSV.
- `2199b6a7-563d-42f8-8fb0-287828054b91_noise_0p2pct.csv`: original data with 0.2% relative Gaussian noise.
- `2199b6a7-563d-42f8-8fb0-287828054b91_noise_0p5pct.csv`: original data with 0.5% relative Gaussian noise.
- `2199b6a7-563d-42f8-8fb0-287828054b91_noise_1pct.csv`: original data with 1% relative Gaussian noise.
- `generation_summary.json`: summary statistics.

## Noise model

```text
V_noisy = V * (1 + epsilon)
epsilon ~ N(0, sigma)
```

## Path note

These files are designed to be read with relative paths, for example:

```python
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
V = pd.read_csv(BASE_DIR / "synthetic_2199b6a7-563d-42f8-8fb0-287828054b91.csv")
```
