# Synthetic filtered datasets v2

This folder contains regenerated synthetic versions of the six uploaded filtered CSV files.

Compared with the previous fully simulated version, these files are intentionally closer to the
original data structure. They preserve the labels, timestamp row, column names, row order, and
main temporal/class patterns, while applying small numerical perturbations.

## Generated files

For each original file, two versions are provided:

- `synthetic_<original_filename>.csv`
  - Close synthetic/anonymized version.
  - Uses small row-level scaling, small row-level offset, smooth relative noise, and a tiny global temporal disturbance.

- `<original_stem>_noise_0p2pct.csv`
  - Conservative 0.2% relative noise-only version.
  - This is the safest option if the goal is to reproduce classification behavior close to the original data.

## Loading with relative paths

```python
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
V = pd.read_csv(BASE_DIR / "synthetic_simulated_filtered_1.csv")
```

No private OneDrive paths or hard-coded personal directories are required.
