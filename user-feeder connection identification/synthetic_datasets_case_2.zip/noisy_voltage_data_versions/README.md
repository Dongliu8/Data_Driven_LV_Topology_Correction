# Noisy voltage data versions

These files preserve the original CSV structure, row labels, meter labels, and timestamp row.

Only the voltage measurements in rows 2:end and columns 2:end are perturbed.

Noise model:

```text
V_noisy = V * (1 + epsilon)
epsilon ~ N(0, sigma)
```

Included versions:

- `simulated_voltage_data_0_noise_0p2pct.csv`: sigma = 0.002
- `simulated_voltage_data_0_noise_0p5pct.csv`: sigma = 0.005
- `simulated_voltage_data_0_noise_1pct.csv`: sigma = 0.010

Use the 0.2% or 0.5% version if you only want to add a small amount of measurement noise while keeping the original labels and data pattern almost unchanged.
